<%--
* Licensed Materials - Property of IBM
* 
* 5724-U18
* 
* (C) COPYRIGHT IBM CORP. 2021,2024 All Rights Reserved.
* 
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
--%><%--
* Use this for the customHeaderPage in conjunction with customHeaderPage.css
* NOTE: This file is intended for client modifications, but they must be maintained by the client as we do not guarantee 
* that it will not change or be overwritten in fix packs or upgrades.
* --%>
<%@ page import="com.ibm.json.java.JSONObject, psdi.server.*, java.util.*, psdi.util.HTML" %>
<%
// JSP / JAVA CODE HERE
// The following is purely example code to help with understanding how it can be used.
JSONObject userJSON = new JSONObject();
s.getUserInfo().toJSON(userJSON, false);
String userFullName = HTML.encode(HTML.cleanHtml(s.getUserInfo().getDisplayName(), false, false));
String defaultSite = HTML.encode(HTML.cleanHtml(s.getProfile().getDefaultSite(), true, false));

String label = MXServer.getMXServer().getProperty("cor.env.ribbon.label");
String color = MXServer.getMXServer().getProperty("cor.env.ribbon.color");

String[] allowed = new String[] {
        "red","magenta","purple","blue","cyan","teal","green","gray","cool-gray","warm-gray","high-contrast","outline"
    };
boolean ok = false;
for (String a : allowed) { if (a.equals(color)) { ok = true; break; } }
if (!ok) color = "cyan";

String tagClass = "bx--tag--" + color + " env-banner"; 
%>

<!-- html here -->
<!-- The following is purely example code to help with understanding how it can be used. -->
<div class="<%=tagClass%>">
    <%=userFullName%> | Site : <%=defaultSite%> | Env. : <%=label%>
</div>
